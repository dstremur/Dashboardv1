
var NARROW_NO_BREAK_SPACE = '\u202F';
var map1 = L.tileLayer("Maps/swisstopotiles/{z}/{x}/{y}.png", {
  tms: 1, opacity: 1  , attribution: "", minZoom: 0, maxZoom: 16
  });
  
  var map2 = L.tileLayer(
    "https://tile.openweathermap.org/map/precipitation_new/{z}/{x}/{y}.png?appid=59dde6635d0c72a182788d2459672a1f",
    {
      maxZoom: 14,
      attribution:
        '&copy; <a href="https://openweathermap.org/api/weathermaps">OpenStreetMap</a>',
    }
  );
  
  var map3 = L.tileLayer(
    "https://tile.openweathermap.org/map/temp_new/{z}/{x}/{y}.png?appid=59dde6635d0c72a182788d2459672a1f",
    {
      maxZoom: 14,
      attribution:
        '&copy; <a href="https://openweathermap.org/api/weathermaps">OpenStreetMap</a>',
    }
  );


  var circleIcon = L.icon({
    iconUrl: 'circle.png',

    iconSize:     [30,30] // size of the icon
});



  
  var map = L.map("map", { center: LV952WGS([2612387, 1167326]), zoom: 11, layers: [map1] });
  
  var baseMaps = {
    Normal: map1,
  };
  
  
  L.control.scale({ imperial: false, maxWidth: 200 }).addTo(map);


  function LV952WGS(lonlat){
    var WGS = swissgrid.unproject(lonlat);
    return [WGS[1], WGS[0]]
    }


  function WGS2LV95(array){
    var LV = swissgrid.project(array);
    return LV
    }



    function addMouseMoveCoordinates(map) {
      var MouseMoveCoordinatesControl = L.Control.extend({
        onAdd: function (map) {
          var container = L.DomUtil.create('div', 'leaflet-control-mouse-move-coordinates');
          container.style.background = 'rgba(255, 255, 255, 0.9)';
          container.style.border = '2px solid #777';
          container.style.padding = '2px 4px';
          container.style.color = '#333';
          container.style.fontFeatureSettings = 'tnum';
          var updateCoordinates = function (latlng) {
            var formattedCoordinates = formatLv95Coordinates(latlng, NARROW_NO_BREAK_SPACE)
            container.innerHTML = '<b>LV95 Coordinates (E, N)</b><br>' + formattedCoordinates;
          };
          map.on('mousemove', function (event) {
            updateCoordinates(event.latlng);
          });
          updateCoordinates(map.getCenter());
          return container;
        }
      });
    
      new MouseMoveCoordinatesControl().addTo(map);
    }
    
    function formatLv95Coordinates(latlng, separator) {
      var coordinates =  WGS2LV95([latlng.lng, latlng.lat]);
      var formattedCoordinates = coordinates.map(function(coordinate) {
        var parts = [];
        coordinate = String(Math.round(coordinate));
        while (coordinate) {
          parts.unshift(coordinate.slice(-3));
          coordinate = coordinate.slice(0, -3);
        }
        return parts.join(separator);
      });
      return formattedCoordinates.join(', ');
    }
    
    function formatWgs84Coordinates(latlng, addSuffix) {
      var coordinates = [latlng.lat, latlng.lng];
      var suffixes = ['°N', '°E'];
      var formattedCoordinates = coordinates.map(function(coordinate, i) {
        var formatted = coordinate.toFixed(5);
        if (addSuffix) {
          formatted += suffixes[i];
        }
        return formatted;
      });
      return formattedCoordinates.join(', ');
    }

    addMouseMoveCoordinates(map)
   

    

  console.log(WGS2LV95([7,47]))
 





  const marker2 = L.marker([46.373404, 9.199985], {icon: circleIcon}).addTo(map)
  .bindPopup('1')


  // marker2.dragging.enable()

















L.control.zoomLabel().addTo(map);




var layerControl = L.control.layers(baseMaps).addTo(map);

function refreshTime() {
  var today = new Date();
  var h = String(today.getHours());
  var m = String(today.getMinutes());
  var s = String(today.getSeconds());
  h = checkTime(h);
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById("time").innerText = h + m + " " + s;
}

function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  } // add zero in front of numbers < 10
  return i;
}

window.setInterval(() => {
  refreshTime();
});
