function GetWeatherData(lat, lon) {
  // API Key: 59dde6635d0c72a182788d2459672a1f

  // Define the API URL
  const apiUrl1 =
    "https://api.openweathermap.org/data/2.5/forecast?lat=" +
    String(lat) +
    "&lon=" +
    String(lon) +
    "&appid=59dde6635d0c72a182788d2459672a1f&units=metric&lang=de";
  // Make a GET request
  fetch(apiUrl1)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      i = 0;
      d1 = data.list[0];
      d2 = data.list[8];
      d3 = data.list[16];
      d4 = data.list[24];
      d5 = data.list[32];
      for (i = 0; i < 40; i += 8) {}
      BuildTable(data);
      return data;
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}
  

Koordinaten = [
  46.761147, 7.600347, 46.644227, 7.734364, 47.414558, 9.248050, 47.412758, 9.345554
];
document.getElementById("weather1").innerHTML = "";
    
for (i=0; i < Koordinaten.length; i += 2){

  GetWeatherData(Koordinaten[i], Koordinaten[i+1])
}
    
  
  

  
    function BuildTable(data) {
      console.log(data)
      table = document.createElement("table");
      table.className = "table table-success table-bordered align-content-center";
      thead = document.createElement("thead");
      tbody = document.createElement("tbody");
      trh = document.createElement("tr");
      tr1 = document.createElement("tr");
      tr2 = document.createElement("tr");
      tr3 = document.createElement("tr");
      tr4 = document.createElement("tr");
      tr5 = document.createElement("tr");
      tr6 = document.createElement("tr");
      tr7 = document.createElement("tr");
      tr8 = document.createElement("tr");
      tr9 = document.createElement("tr");
    
      i = 0;
      for (i = 0; i < 14; i++) {
        // create thead
        var th = document.createElement("th");
        date = new Date(data.list[i].dt * 1000);
        hours = date.getHours();
        day = date.getDay();
        days = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
        console.log(day, days[day]);
        if (hours < 10) {
          formattedTime = days[day] + " 0" + String(hours) + "00";
        } else {
          formattedTime = days[day] + " " + String(hours) + "00";
        }
        th.appendChild(document.createTextNode(formattedTime));
        trh.appendChild(th);
        thead.appendChild(trh);
    
        // create tbody
        // row 1 (images)
        img = document.createElement("img");
        imgcode = data.list[i].weather[0].icon;
        img.src =
          "https://openweathermap.org/img/wn/" + String(imgcode) + "@2x.png";
        td = document.createElement("td");
        td.appendChild(img);
        tr1.appendChild(td);
        tbody.appendChild(tr1);
    
        td = document.createElement("td");
        td.appendChild(
          document.createTextNode(data.list[i].weather[0].description)
        );
        tr2.appendChild(td);
        tbody.appendChild(tr2);
        // row 2
        td = document.createElement("td");
        td.appendChild(document.createTextNode(data.list[i].main.temp + "°C"));
        tr3.appendChild(td);
        tbody.appendChild(tr3);
    
        td = document.createElement("td");
        td.appendChild(document.createTextNode(data.list[i].main.humidity + "%"));
        tr4.appendChild(td);
        tbody.appendChild(tr4);
    
        // rain permanently deleted
    
        td = document.createElement("td");
        rain = data.list[i].rain;
    
        if (rain === undefined) {
          td.appendChild(document.createTextNode("Kein Niederschlag"));
        } else {
          console.log(rain["3h"]);
          td.appendChild(document.createTextNode(rain["3h"] + "mm"));
        }
    
        tr5.appendChild(td);
        tbody.appendChild(tr5);
    
        // Wind Speed
    
        td = document.createElement("td");
        td.appendChild(document.createTextNode(data.list[i].wind.speed + "km/h"));
        tr6.appendChild(td);
        tbody.appendChild(tr6);
    
        table.appendChild(thead);
        table.appendChild(tbody);
      }
    
      var nameDiv = document.createElement("h2");
      nameDiv.innerText += data.city.name
      document.getElementById("weather1").appendChild(nameDiv);

      document.getElementById("weather1").appendChild(table);
      document.getElementById("weather1").innerHTML += "Updated: " + Date()  + '<br>';
    }
    


    function refreshTime() {
      var today = new Date();
      var h = String(today.getHours());
      var m = String(today.getMinutes());
      var s = String(today.getSeconds());
      h = checkTime(h);
      m = checkTime(m);
      s = checkTime(s);
      document.getElementById("time").innerText = h + m + " " + s;
    }
    
    function checkTime(i) {
      if (i < 10) {
        i = "0" + i;
      } // add zero in front of numbers < 10
      return i;
    }

    window.setInterval(() => {
      refreshTime();
    });




  