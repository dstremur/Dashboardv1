'use strict';

var NARROW_NO_BREAK_SPACE = '\u202F';

// Create map and attach id to element with id "mapid"
var map = L.map('mapid', {
    // Use LV95 (EPSG:2056) projection
    crs: L.CRS.EPSG2056,
  });


  addMouseMoveCoordinates(map);
function addMouseMoveCoordinates(map) {
    var MouseMoveCoordinatesControl = L.Control.extend({
      onAdd: function (map) {
        var container = L.DomUtil.create('div', 'leaflet-control-mouse-move-coordinates');
        container.style.background = 'rgba(255, 255, 255, 0.9)';
        container.style.border = '2px solid #777';
        container.style.padding = '2px 4px';
        container.style.color = '#333';
        container.style.fontFeatureSettings = 'tnum';
        var updateCoordinates = function (latlng) {
          var formattedCoordinates = formatLv95Coordinates(latlng, NARROW_NO_BREAK_SPACE)
          container.innerHTML = '<b>LV95 Coordinates (E, N)</b><br>' + formattedCoordinates;
        };
        map.on('mousemove', function (event) {
          updateCoordinates(event.latlng);
        });
        updateCoordinates(map.getCenter());
        return container;
      }
    });
  
    new MouseMoveCoordinatesControl().addTo(map);
  }
  
  function formatLv95Coordinates(latlng, separator) {
    var EN = L.CRS.EPSG2056.project(latlng);
    var coordinates = [EN.x, EN.y];
    var formattedCoordinates = coordinates.map(function(coordinate) {
      var parts = [];
      coordinate = String(Math.round(coordinate));
      while (coordinate) {
        parts.unshift(coordinate.slice(-3));
        coordinate = coordinate.slice(0, -3);
      }
      return parts.join(separator);
    });
    return formattedCoordinates.join(', ');
  }
  
  function formatWgs84Coordinates(latlng, addSuffix) {
    var coordinates = [latlng.lat, latlng.lng];
    var suffixes = ['°N', '°E'];
    var formattedCoordinates = coordinates.map(function(coordinate, i) {
      var formatted = coordinate.toFixed(5);
      if (addSuffix) {
        formatted += suffixes[i];
      }
      return formatted;
    });
    return formattedCoordinates.join(', ');
  }


  var overlayMaps = {
    'Alps with livestock guardian dogs': L.tileLayer.swiss({
      format: 'png',
      layer: 'ch.bafu.alpweiden-herdenschutzhunde',
      maxNativeZoom: 26,
      opacity: 0.7
    }),
    'Wildlife reserves': L.tileLayer.swiss({
      format: 'png',
      layer: 'ch.bafu.wrz-jagdbanngebiete_select',
      maxNativeZoom: 26,
      opacity: 0.7
    }).addTo(map),
    'Designated wildlife areas': L.tileLayer.swiss({
      format: 'png',
      layer: 'ch.bafu.wrz-wildruhezonen_portal',
      maxNativeZoom: 26,
      opacity: 0.7
    }),
    'Slope classes over 30°': L.tileLayer.swiss({
      format: 'png',
      layer: 'ch.swisstopo.hangneigung-ueber_30',
      maxNativeZoom: 25,
      opacity: 0.4
    })
  };
  
  L.control.layers(baseMaps, overlayMaps, { collapsed: false }).addTo(map);
  
  // Add Swiss layer with default options
  L.tileLayer.swiss().addTo(map);
  
  // Center the map on Switzerland
  map.fitSwitzerland();
  
  // Add a marker with a popup in Bern
  L.marker(L.CRS.EPSG2056.unproject(L.point(2600000, 1200000))).addTo(map)
    .bindPopup('Bern')
    .openPopup();
  