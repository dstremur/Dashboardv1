var tableDiv = document.getElementById("connections");

var allTables = tableDiv.getElementsByTagName('td').length;

console.log(allTables)  


function refreshTime() {
  var today = new Date();
  var h = String(today.getHours());
  var m = String(today.getMinutes());
  var s = String(today.getSeconds());
  h = checkTime(h);
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById("time").innerText = h + m + " " + s;
}

function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  } // add zero in front of numbers < 10
  return i;
}

window.setInterval(() => {
  refreshTime();
});

let boxes = document.getElementsByClassName("form-check-label").length;

function save() {
  for (let i = 1; i <= boxes; i++) {
    var checkbox = document.getElementById(String(i));
    localStorage.setItem("checkbox" + String(i), checkbox.checked);
  }
}

//for loading
for (let i = 1; i <= boxes; i++) {
  if (localStorage.length > 0) {
    var checked = JSON.parse(localStorage.getItem("checkbox" + String(i)));
    document.getElementById(String(i)).checked = checked;
  }
}
window.addEventListener("change", save);

// var map1 = L.tileLayer("Maps/OSM Tile Server Schweiz/{z}/{x}/{y}.png", {
//   maxZoom: 16,
//   attribution:
//     '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
// });

// var map2 = L.tileLayer(
//   "https://tile.openweathermap.org/map/precipitation_new/{z}/{x}/{y}.png?appid=59dde6635d0c72a182788d2459672a1f",
//   {
//     maxZoom: 16,
//     attribution:
//       '&copy; <a href="https://openweathermap.org/api/weathermaps">OpenStreetMap</a>',
//   }
// );

// var map3 = L.tileLayer(
//   "https://tile.openweathermap.org/map/temp_new/{z}/{x}/{y}.png?appid=59dde6635d0c72a182788d2459672a1f",
//   {
//     maxZoom: 16,
//     attribution:
//       '&copy; <a href="https://openweathermap.org/api/weathermaps">OpenStreetMap</a>',
//   }
// );

// var map = L.map("map", { center: [47, 7.32], zoom: 11, layers: [map1] });

// var baseMaps = {
//   Normal: map1,
// };

// var overlayMaps = {
//   Niederschlag: map2,
//   Temperatur: map3,
// };

// var layerControl = L.control.layers(baseMaps, overlayMaps).addTo(map);

/**
 * ---------------------------------------
 * This demo was created using amCharts 4.
 *
 * For more information visit:
 * https://www.amcharts.com/
 *
 * Documentation is available at:
 * https://www.amcharts.com/docs/v4/
 * ---------------------------------------
 */

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

var chart = am4core.create("chartdiv", am4charts.XYChart);
chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

chart.paddingRight = 30;
chart.dateFormatter.inputDateFormat = "yyyy-MM-dd HHmm";

var colorSet = new am4core.ColorSet();
colorSet.saturation = 0.4;

chart.dataSource.parser.options.useColumnNames = true;
chart.dataSource.disableCache = true

chart.data = [
  {
    name: "Ruhe",
    fromDate: "2025-04-14 2300",
    toDate: "2025-04-15 0600",
    color: colorSet.getIndex(2).brighten(0),
  }
];

var categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "name";
categoryAxis.renderer.grid.template.location = 0;
categoryAxis.renderer.inversed = true;
categoryAxis.renderer.minorGridEnabled = true;
categoryAxis.renderer.minGridDistance = 30;

var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
dateAxis.dateFormatter.dateFormat = "hmma";
dateAxis.renderer.minGridDistance = 100;
dateAxis.baseInterval = { count: 30, timeUnit: "minute" };

var range = dateAxis.axisRanges.create();
range.date = new Date("2024-10-02 20:00:00");
range.grid.stroke = am4core.color("black");
range.grid.strokeWidth = 2;
range.grid.strokeOpacity = 1;

// Update timeline every second
window.setInterval(() => {
  dateAxis.min = new Date().getTime();
  dateAxis.max = new Date().getTime() + 4 * 24 * 60 * 60 * 1000;

  chart.events.on("ready", function () {
    dateAxis.zoomToDates(
      new Date().getTime(),
      new Date().getTime() + 1 * 24 * 60 * 60 * 1000
    );
  });
});

dateAxis.strictMinMax = true;
dateAxis.renderer.tooltipLocation = 0;

var series1 = chart.series.push(new am4charts.ColumnSeries());
series1.columns.template.width = am4core.percent(80);
series1.columns.template.tooltipText = "{name}: {openDateX} - {dateX}";

series1.dataFields.openDateX = "fromDate";
series1.dataFields.dateX = "toDate";
series1.dataFields.categoryY = "name";
series1.columns.template.propertyFields.fill = "color"; // get color from data
series1.columns.template.propertyFields.stroke = "color";
series1.columns.template.strokeOpacity = 1;

chart.scrollbarX = new am4core.Scrollbar();

function GetWeatherData(lat, lon) {
  // API Key: 59dde6635d0c72a182788d2459672a1f

  // Define the API URL
  const apiUrl1 =
    "https://api.openweathermap.org/data/2.5/forecast?lat=" +
    String(lat) +
    "&lon=" +
    String(lon) +
    "&appid=59dde6635d0c72a182788d2459672a1f&units=metric&lang=de";
  // Make a GET request
  fetch(apiUrl1)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      console.log(data.city.name)
      i = 0;
      d1 = data.list[0];
      d2 = data.list[8];
      d3 = data.list[16];
      d4 = data.list[24];
      d5 = data.list[32];
      for (i = 0; i < 40; i += 8) {}
      BuildTable(data);
      return data;
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

// Eist : 47.373357, 9.200171
// Wil: 47.463559, 9.047881
// Gossau: 47.414558, 9.248050
// St. Gallen: 47.412758, 9.345554








Koordinaten = [
  46.761147, 7.600347, 46.644227, 7.734364, 47.414558, 9.248050, 47.412758, 9.345554
];


selectValue();
console.log(document.getElementById("select").value);

function selectValue() {
  standort = Number(document.getElementById("select").value);
  console.log(standort + 1);
  console.log(Koordinaten[standort], Koordinaten[standort + 1]);

  GetWeatherData(Koordinaten[standort], Koordinaten[standort + 1]);
}

GetWeatherData(Koordinaten[standort], Koordinaten[standort + 1]);
setInterval(function () {
  GetWeatherData(Koordinaten[standort], Koordinaten[standort + 1]);
  console.log(standort);
}, 60000);

function BatteryAlert() {
  var today = new Date();
  hour = today.getHours();
  min = today.getMinutes();
  sec = today.getSeconds();
  if (hour % 6 == 0 && min == 0 && sec < 5) {
    alert("Batterie wechseln!");
  }
}

BatteryAlert();
setInterval(function () {
  BatteryAlert();
}, 1000);

function BuildTable(data, datanow) {
  document.getElementById("weather").innerHTML = "";
  table = document.createElement("table");
  table.className = "table table-success table-bordered align-content-center";
  thead = document.createElement("thead");
  tbody = document.createElement("tbody");
  trh = document.createElement("tr");
  tr1 = document.createElement("tr");
  tr2 = document.createElement("tr");
  tr3 = document.createElement("tr");
  tr4 = document.createElement("tr");
  tr5 = document.createElement("tr");
  tr6 = document.createElement("tr");
  tr7 = document.createElement("tr");
  tr8 = document.createElement("tr");
  tr9 = document.createElement("tr");

  i = 0;
  for (i = 0; i < 5; i++) {
    // create thead
    var th = document.createElement("th");
    date = new Date(data.list[i].dt * 1000);
    hours = date.getHours();
    day = date.getDay();
    days = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
    console.log(day, days[day]);
    if (hours < 10) {
      formattedTime = days[day] + " 0" + String(hours) + "00";
    } else {
      formattedTime = days[day] + " " + String(hours) + "00";
    }
    th.appendChild(document.createTextNode(formattedTime));
    trh.appendChild(th);
    thead.appendChild(trh);

    // create tbody
    // row 1 (images)
    img = document.createElement("img");
    imgcode = data.list[i].weather[0].icon;
    img.src =
      "https://openweathermap.org/img/wn/" + String(imgcode) + "@2x.png";
    td = document.createElement("td");
    td.appendChild(img);
    tr1.appendChild(td);
    tbody.appendChild(tr1);

    td = document.createElement("td");
    td.appendChild(
      document.createTextNode(data.list[i].weather[0].description)
    );
    tr2.appendChild(td);
    tbody.appendChild(tr2);
    // row 2
    td = document.createElement("td");
    td.appendChild(document.createTextNode(data.list[i].main.temp + "°C"));
    tr3.appendChild(td);
    tbody.appendChild(tr3);

    td = document.createElement("td");
    td.appendChild(document.createTextNode(data.list[i].main.humidity + "%"));
    tr4.appendChild(td);
    tbody.appendChild(tr4);

    // rain permanently deleted

    td = document.createElement("td");
    rain = data.list[i].rain;

    if (rain === undefined) {
      td.appendChild(document.createTextNode("Kein Niederschlag"));
    } else {
      console.log(rain["3h"]);
      td.appendChild(document.createTextNode(rain["3h"] + "mm"));
    }

    tr5.appendChild(td);
    tbody.appendChild(tr5);

    // Wind Speed

    td = document.createElement("td");
    td.appendChild(document.createTextNode(data.list[i].wind.speed + "km/h"));
    tr6.appendChild(td);
    tbody.appendChild(tr6);

    table.appendChild(thead);
    table.appendChild(tbody);
  }

  document.getElementById("weather").appendChild(table);
  document.getElementById("weather").innerHTML += "Updated: " + Date();
}

// // First, create your range marker
// var range = dateAxis.axisRanges.create();
// range.grid.stroke = am4core.color("red");
// range.grid.strokeWidth = 2;
// range.grid.strokeOpacity = 1;
// range.date = new Date();

// // Then, update the position of your range marker every second
// range.date = new Date(range.date.getTime() + 1000)
// var timeout = window.setInterval(() => {
//   range.date = new Date(range.date.getTime() + 1000);
//   dateAxis.min = new Date().getTime();
//   dateAxis.max = new Date().getTime() + 604800000;
// }, 1000);

// chart.events.on('beforedisposed', () => {
//    clearTimeout(timeout);
// });

function createListItem(text) {
  var li = document.createElement("li");
  var label = document.createElement("label");
  var input = document.createElement("input");
  input.className = "form-check-input me-1";
  input.setAttribute("value id", "firstCheckbox");
  input.setAttribute("type", "checkbox");
  label.className = "form-check-label";
  label.setAttribute("for", "firstCheckbox");
  li.className = "list-group-item d-flex w-100 justify-content-between";
  li.innerText = input;
  li.appendChild(input);
  li.appendChild(label);
  document.getElementById("Pendenzen").appendChild(li);
}


// Dark Mode







// Verbindungskontrolle

i = 0

Standorte = ["St1_235_"]
colors = ["red", "orange", "green", "green"]

k = 35
console.log("K", k)

function initializeValues() {
  for (j = 0; j <k; j++){
    for (i = 0; i <24; i++ ) {
        localStorage.setItem(Standorte[j] + String(i), " ");
        
    }
  }
    
}

function saveData(){
    for (j = 0; j <k; j++){
    for (i = 0; i <24; i++ ) {
      console.log(Standorte[j] + String(i))
        localStorage.setItem(Standorte[j] + String(i), document.getElementById(Standorte[j] + String(i)).innerText)
        }

      }
    actualValue()
}




function actualValue() {

  for (j = 0; j <k; j++){ 
for (i = 0; i <24; i++ ) {
    //console.log(i, document.getElementById(Standorte[0]+ String(i)).innerText)


        if (document.getElementById(Standorte[j]+ String(i)).innerText == "" || document.getElementById(Standorte[j]+ String(i)).innerText == "\n" ){
            
            var Value = Number(document.getElementById(Standorte[j]+ String(i-1)).innerText)
            console.log("Value:", Value, colors[Value])
            break
        }

        console.log("color", document.getElementById(Standorte[j] +"circle").getAttribute("fill"))

       

}
  
 // Set Color

 
 document.getElementById(Standorte[j] +"circle").setAttribute("fill", colors[Value]);
}
}


// function actualValue() {

//   for (i = 0; i <24; i++ ) {
//       //console.log(i, document.getElementById(Standorte[0]+ String(i)).innerText)
  
  
//           if (document.getElementById(Standorte[0]+ String(i)).innerText == "" || document.getElementById(Standorte[0]+ String(i)).innerText == "\n" ){
              
//               var Value = Number(document.getElementById(Standorte[0]+ String(i-1)).innerText)
//               console.log("Value:", Value, colors[Value])
//               break
//           }
  
//           console.log("color", document.getElementById(Standorte[0] +"circle").getAttribute("fill"))
  
         
  
//   }
  
//    // Set Color
//    document.getElementById(Standorte[0] +"circle").setAttribute("fill", colors[Value]);
//   }
  
  
  
 
  
  
function update(){
      var i = 1
      while (i < 35 ){
        console.log(i)
         
          for (let j = 0; j < 24; j++){
            console.log(j);

            localStorage.setItem("T" + String(i) +"_" + String(j), document.getElementById("T" + String(i) +"_" + String(j)).innerText)
              
  
  
            if (document.getElementById("T" + String(i) +"_" + String(j)).innerText == "" || document.getElementById("T" + String(i) +"_" + String(j)).innerText == "\n" ){ 

              if (j-1 < 0){
                document.getElementById("T" + String(i) +"_" +"circle").setAttribute("fill", "black");
               break
              } 
              
                  var Value = Number(document.getElementById("T" + String(i) +"_" + String(j-1)).innerText)
                  console.log("Value:", "T" + String(i) +"_" +"circle", Value, colors[Value])
                  document.getElementById("T" + String(i) +"_" +"circle").setAttribute("fill", colors[Value]);
                    break
              }

              
      
              console.log("color", "T" + String(i) +"_" +"circle")
      
              
          }

          
  
      i = i + 1 
      }
      
  }

function displayValues() {
  var i = 1
      while (i < 35){
  
    for (var j = 0; j <24; j++ ) {
        
      document.getElementById("T" + String(i) +"_"+ String(j)).innerText = localStorage.getItem("T" + String(i) +"_" + String(j))


      if (document.getElementById("T" + String(i) +"_" + String(j)).innerText == "" || document.getElementById("T" + String(i) +"_" + String(j)).innerText == "\n" ){ 

        if (j-1 < 0){
          document.getElementById("T" + String(i) +"_" +"circle").setAttribute("fill", "black");
         break
        } 
        
            var Value = Number(document.getElementById("T" + String(i) +"_" + String(j-1)).innerText)
            console.log("Value:", "T" + String(i) +"_" +"circle", Value, colors[Value])
            document.getElementById("T" + String(i) +"_" +"circle").setAttribute("fill", colors[Value]);
              break
        }
        
    }

   
    i += 1
  } 
  
}

function clearValues(){
  localStorage.clear();
}


displayValues()










